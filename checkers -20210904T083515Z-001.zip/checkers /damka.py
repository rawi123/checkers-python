from kivy.app import App
from kivy.uix.gridlayout import GridLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.image import Image
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.button import Button
import random
import kivy
import DamkaBina
import time
class Board(GridLayout,FloatLayout):

    def __init__(self,level,**kwargs):
        GridLayout.__init__(self,**kwargs)
        self.level=level
        self.doubleEat=False
        self.mohamad=None
        self.cols=8
        self.firstTouch=None
        self.secondTouch=None
        self.emptyList=[]
        self.playerBlack=[]
        self.turn=0#even-red odd-black
        self.playerRed=[]
        self.board=self.createBoard()
        self.turnStuck=False
        self.queenEat=None
        self.queenAte=None
    def createBoard(self):
        list=[]
        for i in range(8):
            list1=[]
            for j in range(8):
                c=Cell(i,j,source=self.getSource(i,j))
                if(c.source=='soldier black.png'):
                    self.playerBlack.append(c)
                if(c.source=='soldier red.png'):
                    self.playerRed.append(c)
                if(c.source=='white epm.png'):
                    self.emptyList.append(c)
                self.add_widget(c)
                list1.append(c)
            list.append(list1)
        self.add_widget(Label(tex=' '))
        return list
    def getSource(self, i, j):
        if (i < 3):
            if (i % 2 == 0):
                if (j % 2 == 0):
                    so = "soldier black.png"
                else:
                    so = "gray.png"
            elif (i % 2 == 1):
                if (j % 2 == 1):
                    so = "soldier black.png"
                else:
                    so = "gray.png"
        elif (i > 4):
            if (i % 2 == 0):
                if (j % 2 == 0):
                    so = "soldier red.png"
                else:
                    so = "gray.png"
            if (i % 2 == 1):
                if (j % 2 == 1):
                    so = "soldier red.png"
                else:
                    so = "gray.png"
        else:
            if (j % 2 == 0):
                if (i % 2 == 0):
                    so = "white epm.png"
                else:
                    so = "gray.png"
            else:
                if (i % 2 == 0):
                    so = "gray.png"
                else:
                    so = "white epm.png"
        return so
    def burnQueen(self,list1=[]):
        list=[]
        if(self.turn%2==0):
            listOfPlaying=self.playerRed
            cellsource='red queen.png'
        else:
            listOfPlaying=self.playerBlack
            cellsource='black queen.png'
        if(len(list1)==0):
            x = self.secondTouch
            for i in listOfPlaying:
                for j in self.emptyList:
                    if(i.source==cellsource and i not in list):
                        if (abs(i.xnum - j.xnum) == abs(i.ynum - j.ynum)):  # diagnal line
                            #
                            self.secondTouch = j
                            if(self.findDirection(i.xnum, i.ynum)):
                                if(self.queenEat is not None):
                                    self.queenEat=None
                                    list.append(i)
            self.secondTouch=x
            return list
        else:
            x=list1[random.randint(0,len(list1)-1)]
            self.changeLists(x,None,listOfPlaying,self.emptyList,False)
            x.source='white epm.png'


    def burn(self,list1=[]):
        if(self.turn%2==0):
            col=self.playerRed
            notcol=self.playerBlack
        else:
            col = self.playerBlack
            notcol = self.playerRed
        if(len(list1)==0):
            list=[]
            for i in col:
                for j in notcol:
                    if self.canEat1(i,j):
                        list.append(i)
            return list
        else:
            x=list1[random.randint(0,len(list1)-1)]
            if(self.turn%2==0):
                self.changeLists(x,None,self.playerRed,self.emptyList,False)
            else:
                self.changeLists(x, None, self.playerBlack, self.emptyList,False)
            x.source='white epm.png'
            self.checkWin()

    def checkDraw(self):
        for i in self.playerRed:
            for j in self.emptyList:
                if(i.source=='soldier red.png'):
                    f,c=self.canEat('red',i,j)
                    if(f):

                        return False
                    elif(i.xnum==j.xnum+1 and (i.ynum==j.ynum+1 or i.ynum==j.ynum-1)):

                        return False
                else:
                    sSvae=self.secondTouch
                    self.secondTouch=j
                    if(abs(i.xnum-j.xnum)==abs(i.ynum-j.ynum) and self.findDirection(i.xnum,i.ynum)):

                        return False
                    self.secondTouch=sSvae

        return True

    def burnPlaying(self):
        if (self.turn % 2 == 0):
            if (self.firstTouch.source == 'soldier red.png'):
                flag, cell = self.checkCell(Cell(self.firstTouch.xnum - 1, self.firstTouch.ynum - 1), self.playerBlack)
                if (flag):
                    if (self.canEat1(self.firstTouch, cell)):
                        if (self.secondTouch.xnum + 1 == self.firstTouch.xnum):
                            self.firstTouch.source = 'white epm.png'
                            self.changeLists(self.firstTouch, None, self.playerRed, self.emptyList, False)
                            return True
                flag, cell = self.checkCell(Cell(self.firstTouch.xnum - 1, self.firstTouch.ynum + 1), self.playerBlack)
                if (flag):
                    if (self.canEat1(self.firstTouch, cell)):
                        if (self.secondTouch.xnum + 1 == self.firstTouch.xnum):
                            self.firstTouch.source = 'white epm.png'
                            self.changeLists(self.firstTouch, None, self.playerRed, self.emptyList, False)
                            return True
        else:
            if (self.firstTouch.source == 'soldier black.png'):
                flag, cell = self.checkCell(Cell(self.firstTouch.xnum+1, self.firstTouch.ynum-1), self.playerRed)
                if (flag):
                    if (self.canEat1(self.firstTouch, cell)):
                        if (self.secondTouch.xnum-1==self.firstTouch.xnum):
                            self.firstTouch.source='white epm.png'
                            self.changeLists(self.firstTouch,None,self.playerBlack,self.emptyList,False)
                            return True
                flag, cell = self.checkCell(Cell(self.firstTouch.xnum+1,self.firstTouch.ynum+1),self.playerRed)
                if (flag):
                    if (self.canEat1(self.firstTouch, cell)):
                        if (self.secondTouch.xnum-1 == self.firstTouch.xnum):
                            self.firstTouch.source = 'white epm.png'
                            self.changeLists(self.firstTouch, None, self.playerBlack, self.emptyList, False)
                            return True
        return False

    def checkWin(self):
        if(len(self.playerBlack)==0):

            self.parent.endGame('red')
        elif(len(self.playerRed)==0):

            self.parent.endGame('black')

    def move(self,color):
        if(color=='red'):
            self.firstTouch.source='white epm.png'
            self.secondTouch.source='soldier red.png'
            self.playerRed.append(self.secondTouch)
            self.playerRed.remove(self.firstTouch)

        elif(color=='black'):
            self.firstTouch.source='white epm.png'
            self.secondTouch.source='soldier black.png'
            self.playerBlack.append(self.secondTouch)
            self.playerBlack.remove(self.firstTouch)
        self.emptyList.append(self.firstTouch)
        self.emptyList.remove(self.secondTouch)

    def queenMove(self):
        i,j=self.firstTouch.xnum,self.firstTouch.ynum
        check=False

        flag=False
        if(self.turn%2==0):
            turn='red'
        else:
            turn='black'
        if (abs(i-self.secondTouch.xnum)== abs(j-self.secondTouch.ynum)):#diagnal line
            flag=self.findDirection(i,j)
        if(flag):
            if(turn == 'red'):
                if (self.queenEat is not None):

                    self.doubleEat=True
                    self.queenAte=True
                    self.mohamad = self.secondTouch
                    self.queenEat.source = 'white epm.png'
                    self.changeLists(self.queenEat, None, self.playerBlack, self.emptyList, False)
                    self.turn-=1
                self.changeLists(self.firstTouch, self.secondTouch, self.playerRed, self.emptyList)
            else:
                if (self.queenEat is not None):
                    self.doubleEat=True
                    self.queenAte=True
                    self.mohamad=self.secondTouch
                    self.queenEat.source = 'white epm.png'
                    self.changeLists(self.queenEat, None, self.playerRed, self.emptyList, False)
                    self.turn-=1
                self.changeLists(self.firstTouch, self.secondTouch, self.playerBlack, self.emptyList)
            self.firstTouch.source = 'white epm.png'
            col=turn+' queen.png'
            self.secondTouch.source = col
            self.queenEat=None
            return True
        self.checkWin()

    def findDirection(self,i,j):
        flag=False
        if (i < self.secondTouch.xnum):
            if (j < self.secondTouch.ynum):
                if (self.legalQueenMove1(i + 1, j + 1)):
                    flag = True
            else:
                if (self.legalQueenMove2(i + 1, j - 1)):
                    flag = True

        else:
            if (j < self.secondTouch.ynum):
                if (self.legalQueenMove3(i - 1, j + 1)):
                    flag = True
            else:
                if (self.legalQueenMove4(i - 1, j - 1)):
                    flag = True
        return flag

    def legalQueenMove1(self,i,j,counter=0):#x+1 y+1
        if(self.turn%2==0):
            flag, c = self.checkCell(Cell(i, j), self.playerRed)
            flag1,c1=self.checkCell(Cell(i,j),self.playerBlack)
        else:
            flag, c = self.checkCell(Cell(i, j), self.playerBlack)
            flag1,c1=self.checkCell(Cell(i,j),self.playerRed)
        if(counter==2):
            self.queenEat=None
            return False
        if(i==self.secondTouch.xnum and j==self.secondTouch.ynum):
                return True
        elif(flag):
            self.queenEat = None
            return False
        if(flag1):
            counter+=1
            self.queenEat=c1

        return self.legalQueenMove1(i+1,j+1,counter=counter)

    def legalQueenMove2(self,i,j,counter=0):#x+1 y-1

        if(self.turn%2==0):

            flag, c = self.checkCell(Cell(i, j), self.playerRed)
            flag1,c1=self.checkCell(Cell(i,j),self.playerBlack)
        else:

            flag, c = self.checkCell(Cell(i, j), self.playerBlack)
            flag1,c1=self.checkCell(Cell(i,j),self.playerRed)
        if(counter==2):
            self.queenEat = None
            return False
        if(i==self.secondTouch.xnum and j==self.secondTouch.ynum):
            return True
        elif(flag):
            self.queenEat = None
            return False
        if(flag1):
            counter+=1
            self.queenEat=c1

        return self.legalQueenMove2(i+1,j-1,counter=counter)

    def legalQueenMove3(self, i, j, counter=0):  # x-1 y+1
        if(self.turn%2==0):
            flag, c = self.checkCell(Cell(i, j), self.playerRed)
            flag1,c1=self.checkCell(Cell(i,j),self.playerBlack)
        else:
            flag, c = self.checkCell(Cell(i, j), self.playerBlack)
            flag1,c1=self.checkCell(Cell(i,j),self.playerRed)
        if (counter == 2):
            self.queenEat=None
            return False
        if (i == self.secondTouch.xnum and j == self.secondTouch.ynum):
            return True

        elif (flag):
            self.queenEat = None
            return False
        if (flag1):
            counter += 1

            self.queenEat = c1

        return self.legalQueenMove3(i - 1, j + 1, counter=counter)

    def legalQueenMove4(self, i, j,counter=0):  # x-1 y-1
        if(self.turn%2==0):
            flag, c = self.checkCell(Cell(i, j), self.playerRed)
            flag1,c1=self.checkCell(Cell(i,j),self.playerBlack)
        else:
            flag, c = self.checkCell(Cell(i, j), self.playerBlack)
            flag1,c1=self.checkCell(Cell(i,j),self.playerRed)
        if (counter == 2):
            self.queenEat = None
            return False
        if (i == self.secondTouch.xnum and j == self.secondTouch.ynum):
            return True

        elif (flag):
            self.queenEat = None
            return False
        if (flag1):
            counter += 1
            self.queenEat = c1

        return self.legalQueenMove4(i - 1, j - 1,counter=counter)

    def changeLists(self,cell1,cell2,list1,list2,flag=True):#cell 1 removed from list 1 and appended to list 2 , nad the same thing about cell 2 and list 2

        if(flag):
            list1.remove(cell1)
            list2.remove(cell2)
            list1.append(cell2)
            list2.append(cell1)
        else:
            list1.remove(cell1)
            list2.append(cell1)


    def legalMove(self):
        self.checkWin()
        i=self.firstTouch
        i1=self.secondTouch
        list=self.burn()
        list1=self.burnQueen()
        flag1=False
        flag=False
        print i.source
        if(i.source=='red queen.png' or i.source=='black queen.png'):
            if(self.queenMove()):
                if (i in list1):
                    if (self.queenAte == None):
                        self.burnQueen(list1=[self.secondTouch])
                elif (i not in list1 and len(list1) != 0 and self.secondTouch.source!='gray.png'):
                    self.burnQueen(list1)
                elif(len(list) !=0):
                    self.burn(list)
                self.checkWin()
                return True
        elif(i.source=='soldier red.png'):
            if(i.xnum==i1.xnum+1 and (i.ynum==i1.ynum+1 or i.ynum==i1.ynum-1)):
                if(len(list1)!=0):
                    self.burnQueen(list1)
                    flag=False
                    list1=[]
                else:flag=self.burnPlaying()
                if not flag:
                    self.move('red')
                    flag1=True
            elif(i.xnum==i1.xnum+2):
                flag,cell=self.canEat('red',i,i1)
                if(flag):
                    self.eat('red',cell)
                    flag1=True
            self.printl(list1)
            if (i not in list1 and len(list1) != 0 and self.secondTouch.source!='gray.png' and not flag):
                self.burnQueen(list1)
            elif (i not in list and len(list) != 0 and self.secondTouch.source!='gray.png' and not flag):
                self.burn(list)
            self.checkQueen()
            if(flag1 and not flag):
                self.checkWin()
            self.queenAte=None
            return (flag1 or flag)


    def checkQueen(self):
        if(self.secondTouch.source=='soldier red.png'):
            if(self.secondTouch.xnum==0):
                self.secondTouch.makeQueen('red')
                if(self.doubleEat==True):
                    self.doubleEat=False
                    self.turn+=1

    def checkBurnMultiEat(self):
        if (self.checkCanEat()):
            if(self.turn%2==0):
                self.changeLists(self.firstTouch, None, self.playerRed, self.emptyList, False)
            self.firstTouch.source = 'white epm.png'

    def multiEat(self):

        h=False
        i,j=self.firstTouch,self.secondTouch
        if(self.secondTouch.xnum<self.firstTouch.xnum):
            flag,cell=self.canEat('red',i,j)
            if(flag):

                self.eat('red',cell,True)
                self.mohamad=self.secondTouch
            else:
                h = True
        else:
            h = True
        if (h == True):

            self.doubleEat = False
            self.checkBurnMultiEat()
            self.turn += 1
        self.checkQueen()
        self.checkWin()

    def checkCanEat(self):
        for i in self.emptyList:
            if(self.turn%2==0):
                if(i.xnum<self.firstTouch.xnum):
                        flag,cell=self.canEat('red',self.firstTouch,i)
                        if(flag):
                            return True
        return False

    def multiEatQueen(self):
        list = self.burnQueen()
        if (abs(self.firstTouch.xnum - self.secondTouch.xnum) == abs(self.firstTouch.ynum - self.secondTouch.ynum)):
            flag=self.findDirection(self.firstTouch.xnum,self.firstTouch.ynum)
            if(flag and self.queenEat is not None):

                self.queenMove()
                self.queenEat=None
                self.mohamad=self.secondTouch
                self.turn += 1

            else:


                if self.firstTouch in list:
                    self.burnQueen(list=self.firstTouch)
                self.doubleEat=False
                self.turn+=1
        else:
            if self.firstTouch in list:
                self.burnQueen(list=self.firstTouch)

            self.doubleEat = False
            self.turn+=1


    def eat(self,color,cell,flag=False):#cell 1 is the cell you want to eat
        self.emptyList.remove(self.secondTouch)
        if(color=='red'):
            self.firstTouch.source='white epm.png'
            self.secondTouch.source='soldier red.png'
            cell.source='white epm.png'
            self.playerRed.remove(self.firstTouch)
            self.playerBlack.remove(cell)
            self.playerRed.append(self.secondTouch)
        self.emptyList.append(self.firstTouch)
        self.emptyList.append(cell)
        self.doubleEat=True
        self.mohamad=self.secondTouch
        if(flag==False):
            self.turn-=1
        self.checkWin()
    def printl(self,list):
        for i in list:
            print i.xnum,i.ynum.i.source

    def canEat1(self,i,j):
        if (self.turn%2==0):
            if(i.xnum==j.xnum+1):
                if (i.ynum == j.ynum - 1):
                    flag, cell = self.checkCell(Cell(i.xnum - 2, i.ynum + 2), self.emptyList)
                    if (flag):
                        return True
                elif (i.ynum == j.ynum + 1):
                    flag, cell = self.checkCell(Cell(i.xnum - 2, i.ynum - 2), self.emptyList)
                    if (flag):
                        return True

        else:
            if(i.xnum==j.xnum-1):
                if(i.ynum==j.ynum+1):
                    flag,cell=self.checkCell(Cell(i.xnum+2,i.ynum-2),self.emptyList)
                    if(flag):
                        return True
                elif(i.ynum==j.ynum-1):
                    flag, cell = self.checkCell(Cell(i.xnum + 2, i.ynum+2), self.emptyList)
                    if (flag):
                        return True
        return False

    def applyBina(self,b):

        black,red,empty=b[0],b[1],b[2]
        for i in black:
            if(i[0]==7):
                x='black queen.png'
            elif(i[2]==False):
                x='soldier black.png'
            else:
                x='black queen.png'
            self.board[i[0]][i[1]].source =x
            i=self.changeBinaLists(i,x)
            self.playerBlack.append(i)

        for i in red:
            if(i[0]==0):
                x='red queen.png'
            elif (i[2] == False):
                x='soldier red.png'
            else:
                x='red queen.png'
            self.board[i[0]][i[1]].source =x
            i=self.changeBinaLists(i,x)
            self.playerRed.append(i)

        for i in empty:
            self.board[i[0]][i[1]].source='white epm.png'
            i=self.changeBinaLists(i,x)
            self.emptyList.append(i)
        self.checkWin()
    def changeBinaLists(self,cell1,source1):
        flag,i=self.checkCell(Cell(cell1[0],cell1[1],source=source1),self.playerBlack)
        if(flag):
            self.playerBlack.remove(i)
            return i
        flag,i=self.checkCell(Cell(cell1[0],cell1[1],source=source1),self.playerRed)
        if(flag):
            self.playerRed.remove(i)
            return i
        flag,i=self.checkCell(Cell(cell1[0],cell1[1],source=source1),self.emptyList)
        if(flag):
            self.emptyList.remove(i)
            return i
    def canEat(self,color,i,j):
        if(color=='red'):

            if(i.xnum==j.xnum+2):
                if(i.ynum==j.ynum-2):
                    flag,cell=self.checkCell(Cell(i.xnum-1,i.ynum+1),self.playerBlack)
                    if(flag):
                        return True,cell
                elif(i.ynum==j.ynum+2):
                    flag,cell=self.checkCell(Cell(i.xnum-1,i.ynum-1),self.playerBlack)
                    if(flag):
                        return True,cell

        elif(color=='black'):
            if(i.xnum==j.xnum-2):
                if(i.ynum==j.ynum-2):
                    flag,cell=self.checkCell(Cell(i.xnum+1,i.ynum+1),self.playerRed)
                    if(flag):

                        return True,cell
                elif(i.ynum==j.ynum+2):
                    flag,cell=self.checkCell(Cell(i.xnum+1,i.ynum-1),self.playerRed)

                    if(flag):

                        return True,cell
        return False,0

    def wrongTurn(self,turn):
        self.parent.wrong(turn)

    def checkCell(self,cell2,list):
        for i in list:
            if(i.xnum==cell2.xnum and i.ynum==cell2.ynum):
                return True,i
        return False,0

class Cell(ButtonBehavior,Image):
    def __init__(self,xnum,ynum,**kwargs):
        ButtonBehavior.__init__(self,**kwargs)
        Image.__init__(self,**kwargs)
        self.allow_stretch=True
        self.keep_ratio=False
        self.xnum=xnum
        self.ynum=ynum

    def Move(self,i):
        if(self.parent.turn%2==0):
            turn='red'
            notTurn='black'
        else:
            turn='black'
            notTurn='red'
        col='soldier '+notTurn+'.png'
        col1, col2 = 'soldier ' + turn + '.png', turn + ' queen.png'
        if (self.source ==col):
            self.parent.turnStuck = True
            if (i is not None):
                self.parent.wrongTurn('illegal')
            else:
                self.parent.wrongTurn(turn)
            self.parent.firstTouch = None
            self.parent.secondTouch = None
            return
        elif (self.source == col1 or self.source==col2):
            self.parent.firstTouch = self
        elif (self.parent.firstTouch != None):
            self.parent.secondTouch = self
            if(self.parent.secondTouch.source=='white epm.png'):
                if (self.parent.legalMove()):
                    self.parent.firstTouch = None
                    self.parent.secondTouch = None
                    self.parent.turn+=1

    def doubleEat1(self):
        flag=False
        bool=True
        self.parent.firstTouch = self.parent.mohamad
        self.parent.secondTouch = self
        if (self.parent.firstTouch.source == 'soldier red.png'):
            if(self.source=='white epm.png'):
                self.parent.multiEat()
            else:
                bool=False
        elif (self.parent.firstTouch.source == 'red queen.png'):
            if (self.source == 'white epm.png'):
                self.parent.multiEatQueen()
            elif(self.source=='soldier black.png' or self.source=='black queen.png' or self.source=='gray.png'):
                list=self.parent.burnQueen()
                if(self.parent.firstTouch in list):
                    self.parent.burnQueen(list)

                self.parent.firstTouch = self
                self.parent.secondTouch=None
                self.parent.doubleEat = False
                self.parent.turn+=1
                return
            elif(self.source=='soldier red.png' or self.source=='red queen.png'):
                list = self.parent.burnQueen()
                if (self.parent.firstTouch in list):
                    self.parent.burnQueen(list)
                self.parent.doubleEat=False
                self.parent.turn+=1
        if(bool==False):
            self.parent.checkBurnMultiEat()
            self.parent.firstTouch=self
            self.parent.secondTouch=None
            self.parent.doubleEat=False
            self.parent.turn+=1
            return

        if (self.parent.doubleEat is False):

            flag = True
        if (flag == True):
            self.parent.firstTouch = None
            self.parent.secondTouch = None

    def on_press(self):
        #
        if (self.parent.turn % 2 == 0):
            turn = 'red'
        else:
            turn = 'black'
        if(turn=='black'):
            b = DamkaBina.DamkaBina.copyBoard(self.parent.board, turn, self.parent.level)
            if(type(b)==int):
                self.parent.parent.endGame('draw')
            self.parent.applyBina(b)
            self.parent.turn+=1
        elif(self.parent.checkDraw()):
            self.parent.parent.endGame('draw')
        i = self.parent.firstTouch
        if(self.parent.turnStuck):
            self.parent.wrongTurn('remove')
            self.parent.turnStuck=False
            return

        elif(self.parent.doubleEat):
            #
            self.doubleEat1()
        else:
            #
            self.Move(i)





    def makeQueen(self,color):
        if(color=='red'):
            self.source='red queen.png'
        else:
            self.source='black queen.png'


class Main(FloatLayout,ButtonBehavior):
    def __init__(self,**kwargs):
        FloatLayout.__init__(self,**kwargs)
        self.b=None
        pic=Image(source='back.png')
        pic.allow_stretch=True
        pic.keep_ratio=False
        self.add_widget(pic)
        button1 = Button(text='', size_hint=(.278, .15), pos_hint={'x': .72, 'y': .494}, background_color=(0,0,0,0))
        self.add_widget(button1)
        button1.bind(on_press=self.clear1)
        button2 = Button(text='', size_hint=(.34, .14),pos_hint={'x': .59, 'y': .3},background_color=(0,0,0,0))
        self.add_widget(button2)
        button2.bind(on_press=self.clear3)
        button3 = Button(text='', size_hint=(.334, .13), pos_hint={'x': .49, 'y': .12}, background_color=(0,0,0,0))
        self.add_widget(button3)
        button3.bind(on_press=self.clear3)
    def clear1(self,s):
        self.clear(2)
    def clear2(self,s):
        self.clear(3)
    def clear3(self,s):
        self.clear(4)
    def endGame(self,winner):
        self.clear_widgets()
        if(winner=='black'):
            x=Image(source='black win.png')
        elif(winner=='red'):
            x=Image(source='red win.png')
        else:
            x=Image(source='draw.png')
        x.allow_stretch=True
        x.keep_ratio=False
        self.add_widget(x)
        self.restart()

    def restart(self):
        button1 = Button(text='start Again', size_hint=(.2, .2),pos_hint={'x': .1, 'y': .1},color=(0,0,1,1),background_color=(1,5,2,3))
        self.add_widget(button1)
        button1.bind(on_press=self.clear2)


    def wrong(self,turn):
        x=None
        if(turn=='black'):
            x=Image(source='black turn.png')
        elif(turn=='red'):
            x = Image(source='red turn.png')
        elif(turn=='illegal'):
            x=Image(source='illegal move.png')
        elif(turn=='remove'):
            self.remove_widget(self.children[0])
        if(x is not None):
            x.keep_ratio=False
            self.add_widget(x)

    def surrnder(self,s):
        turn=self.children[-1]
        if(turn.turn%2!=0):
            self.endGame('red')
        else:
            self.endGame('black')

    def clear(self,level):
        self.clear_widgets()
        self.add_widget(Board(level))
        img=Image(source='surrnder.png',size_hint=(1, .12),pos_hint={'x': 0, 'y': 0},background_color=(0,0,0,0))
        img.allow_stretch=True
        img.keep_ratio=False
        self.add_widget(img)
        button = Button(text=' ', size_hint=(1, .12),pos_hint={'x': 0, 'y': 0},background_color=(0,0,0,0))
        self.add_widget(button)
        button.bind(on_press=self.surrnder)

class TestApp(App):
    def build(self):
        self.title="checkers by rawi"
        return Main()
TestApp().run()