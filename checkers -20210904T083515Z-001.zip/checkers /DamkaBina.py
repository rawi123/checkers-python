import copy
import random
class DamkaBina:
    @staticmethod
    # computer move
    def minimax(game_state, depth, com='black'):
        alpha = float('-inf')
        beta = float('inf')
        moves = DamkaBina.moves(game_state, com)
        if(len(moves)==0):
            return 1,-1
        best_move = moves[0]
        best_score = float('-inf')
        for move in moves:
            clone = DamkaBina.next_State(game_state,move,com,moves)
            score = DamkaBina.min_play(clone, depth - 1,'red', alpha, beta)
            if score > best_score:
                best_move = move
                best_score = score
            if alpha < best_score:
                alpha = best_score;
            if beta <= alpha:

                break;
        return (best_move, best_score)

    @staticmethod
    # human move
    def min_play(game_state, depth, human, alpha, beta):

        if depth == 0 or DamkaBina.gameOver(game_state):
            return DamkaBina.evaluate(game_state,'red')
        moves = DamkaBina.moves(game_state,human)
        best_score = float('inf')
        for move in moves:

            clone = DamkaBina.next_State(game_state,move,human,moves)
            score = DamkaBina.max_play(clone, depth - 1, 'black', alpha, beta)
            if score < best_score:
                best_score = score
            if beta > best_score:
                beta = best_score;
            if beta <= alpha:
                break;
        return best_score;

    @staticmethod
    # computer move
    def max_play(game_state, depth, comp, alpha, beta):
        if depth == 0 or DamkaBina.gameOver(game_state):
            return DamkaBina.evaluate(game_state,'black')
        moves = DamkaBina.moves(game_state,comp)
        best_score = float('-inf')
        for move in moves:
            clone = DamkaBina.next_State(game_state,move,comp,moves)
            score = DamkaBina.min_play(clone, depth - 1, 'red', alpha, beta)
            if score > best_score:
                best_score = score
            if alpha < best_score:
                alpha = best_score;
            if beta <= alpha:
                break;
        return best_score;

    @staticmethod
    def copyBoard(board1,turn,level):
        black, red, empty = [], [], []
        for i in board1:
            for j in i:
                x = (j.xnum, j.ynum, ((j.source == 'red queen.png') or (j.source == 'black queen.png')))
                if (j.source == 'soldier black.png' or j.source == 'black queen.png'):
                    black.append(x)
                elif (j.source == 'soldier red.png' or j.source == 'red queen.png'):
                    red.append(x)
                elif (j.source == 'white epm.png'):
                    empty.append(x)
        board = (black, red, empty)
        b,k=DamkaBina.minimax(board,level)

        if(type(b)==int):
            return k
        return DamkaBina.next_State(board,b,turn)

    @staticmethod
    def burnPlaying(board,turn,i,bool=True):
        if(bool==True):
            for j in board[2]:
                if(DamkaBina.canEat1(board,turn,i,j)):
                    return (i,j)
        else:
            if(turn=='black'):
                turn1=0
            else:
                turn1=1
            board[turn1].remove[i]
            board[2].append[i]

    @staticmethod
    def burnQueen(board,turn,list1=[]):
        list = []
        if(turn=='black'):
            turn1=0
        else:
            turn1=1
        b=copy.deepcopy(board)
        if (len(list1) == 0):
            for i in b[turn1]:
                    if(i[2]==True):
                        for j in b[2]:
                            if(abs(i[0]-j[0])==abs(i[1]-j[1])):
                                if(DamkaBina.findDirection(i,j,turn,b)=='eat'):
                                    list.append(i)
                                    break

            return list
        else:
            x = list1[random.randint(0, len(list1) - 1)]
            if (turn == 'red'):
                board[1].remove(x)
                board[2].append((x[0],x[1],False))
            else:
                board[0].remove(x)
                board[2].append((x[0],x[1],False))

    @staticmethod
    def burn(board,turn,list1=[]):
        if (turn=='black'):
            col=0
            notCol=1
        else:
            col = 1
            notCol = 0
        if (len(list1) == 0):
            list = []
            for i in board[col]:
                for j in board[notCol]:
                    if DamkaBina.canEat1(board,turn,i,j):
                        list.append(i)
            return list
        else:
            x = list1[random.randint(0, len(list1)-1)]
            if (turn=='red'):
                board[1].remove(x)
                board[2].append(x)
            else:
                board[0].remove(x)
                board[2].append(x)

    @staticmethod
    def canEat1(board,turn, i, j):
        if (turn=='red'):
            if(j in board[2]):
                if (i[0] == j[0]+2):
                    if (j[1] == i[1] + 2):
                        xRight = (i[0]-1,i[1]+1,i[2])
                        xRight1 = (i[0]-1,i[1]+1,True)
                        if (xRight1 in board[0] or xRight in board[0]):
                            return True
                    elif (j[1]==i[1]-2):
                        xLeft = (i[0]-1,i[1]-1,i[2])
                        xLeft1 = (i[0]-1,i[1]-1,True)
                        if (xLeft in board[0] or xLeft1 in board[0]):
                            return True
            else:
                if (i[0] == j[0] + 1):
                    if (i[1] == j[1] - 1):
                        if ((i[0] - 2, i[1] + 2, False) in board[2]):
                            return True
                    elif (i[1] == j[1] + 1):
                        if ((i[0] - 2, i[1] - 2, False) in board[2]):
                            return True

        else:
            if(j in board[2]):
                if(i[0]==j[0]-2):
                    if(j[1]==i[1]+2):
                        xRight=(i[0]+1,i[1]+1,i[2])
                        xRight1 = (i[0] + 1, i[1] + 1, True)
                        if(xRight1 in board[1] or xRight in board[1]):
                            return True
                    elif(j[1]==i[1]-2):
                        xLeft = (i[0]+1,i[1]-1,i[2])
                        xLeft1 = (i[0] + 1, i[1] - 1, True)
                        if(xLeft in board[1] or xLeft1 in board[1]):
                            return True
            else:
                if (i[0] == j[0] - 1):
                    if (i[1] == j[1] + 1):
                        if ((i[0] + 2, i[1] - 2, False) in board[2]):
                            return True
                    elif (i[1] == j[1] - 1):
                        if ((i[0] + 2, i[1] + 2, False) in board[2]):
                            return True
        return False

    @staticmethod
    def moves(board,turn):
        list1=[]
        if(turn=='black'):
            num=0
        else:
            num=1
        for i in board[num]:
            for j in board[2]:
                dontChange = 0
                if(DamkaBina.legalMoves(i,j,turn,board)):
                    list1.append([i,j])
                    if(j[0]!=7 and j[0]!=0 and i[2]==False and abs(i[0]-j[0])==2):

                        b=copy.deepcopy(board)
                        b=DamkaBina.next_State(b,list1[-1],turn)
                        l=copy.deepcopy(list1[-1])
                        l=[l]
                        h=(j[0],j[1],False)
                        DamkaBina.soldierMultiEat(h,b,turn,l,list1)
                    elif(i[2]==True and DamkaBina.findDirection(i,j,turn,board)=='eat'):
                        b = copy.deepcopy(board)
                        b=DamkaBina.next_State(b,list1[-1],turn)
                        h=(j[0],j[1],True)
                        l=copy.deepcopy(list1[-1])
                        l=[l]
                        DamkaBina.queenMultiEat1(h,b,turn,l,list1)



        return list1

    @staticmethod
    def soldierMultiEat(soldier,board,turn,move,list1):
        if(DamkaBina.canEat(soldier,board,turn)==False):

            return
        else:
            for j in board[2]:
                if(abs(soldier[0]-j[0])==2):
                    if(DamkaBina.legalMoves(soldier,j,turn,board)):

                        move.append([soldier,j])

                        if((turn=='black' and j[0]==7) or (turn=='red' and j[0]==0)):
                            move.pop()
                            move.append([soldier,(j[0],j[1],True)])
                            list1.append(copy.deepcopy(move))
                            move.pop()
                            return
                        else:
                            list1.append(copy.deepcopy(move))
                            DamkaBina.soldierMultiEat((j[0],j[1],False),DamkaBina.next_State(board,move[-1],turn),turn,move,list1)
                            move.pop()
            return
    @staticmethod
    def queenMultiEat1(queen,board,turn,move,list1):
        if(DamkaBina.queenCanEat(queen,board,turn) is False):
            return
        else:
            for i in board[2]:
                if(DamkaBina.queenMove(queen,i,turn,board)=='eat'):
                    move.append([queen,i])
                    list1.append(copy.deepcopy(move))
                    DamkaBina.queenMultiEat1((i[0],i[1],True),DamkaBina.next_State(board,move[-1],turn),turn,move,list1)
                    if(len(move)>1):
                        move.pop()
            return
    @staticmethod
    def canEat(i,board,turn):
        for j in board[2]:
            if(DamkaBina.canEat1(board,turn,i,j)):
                return True
        return False
    @staticmethod
    def queenCanEat(queen,board,turn):
        for i in board[2]:
            if(DamkaBina.queenMove(queen,i,turn,board)=='eat'):
                return True
        return False
    @staticmethod
    def gameOver(board):
        if(len(board[1])==0):
            return True
        elif(len(board[0])==0):
            return True
        return False
    @staticmethod
    def next_State(board,move,turn,list3=[]):
        #list3 all the moves
        newBoard=copy.deepcopy(board)
        if(turn=='black'):
            turn1=0
            notTurn=1
        else:
            turn1=1
            notTurn=0
        k=copy.deepcopy(move)
        ksave=copy.deepcopy(k)
        while(len(k)!=0):
            if type(k[0]) == list:
                move = k[0]
            else:
                move = k
            list2=DamkaBina.burn(newBoard,turn)
            list1=DamkaBina.burnQueen(newBoard,turn)
            if (move[0][0] < move[1][0]):
                if (move[0][1] < move[1][1]):
                    x = 1
                    y = 1
                else:
                    x = 1
                    y = -1
            else:
                if (move[0][1] < move[1][1]):
                    x = -1
                    y = 1
                else:
                    x = -1
                    y = -1
            if(move[0][2]==True):
                if(DamkaBina.queenMove(move[0],move[1],turn,board)!='eat'):
                    if (move[0] in list1):
                        DamkaBina.burnQueen(newBoard, turn,[move[0]])
                        return newBoard
                    elif (move[0] not in list1 and len(list1) != 0):
                        DamkaBina.burnQueen(newBoard, turn, list1)
                    elif(len(list2)!=0):
                        DamkaBina.burn(newBoard,turn,list2)
            else:
                if(abs(move[0][0]-move[1][0])!=2):
                    if(len(list1)!=0):
                        DamkaBina.burnQueen(newBoard,turn,list1)
                    elif(move[0] in list2):
                        DamkaBina.burn(newBoard,turn,[move[0]])
                        return newBoard
                    elif(move[0] not in list2 and len(list2)!=0):
                        DamkaBina.burn(newBoard,turn,list2)
            change2=(move[0][0],move[0][1])
            while(change2[0]!=move[1][0]):
                change = (change2[0], change2[1], True)
                change1 = (change2[0], change2[1], False)
                if(change in newBoard[notTurn]):
                    newBoard[notTurn].remove(change)
                    newBoard[2].append((change[0],change[1],False))
                elif (change1 in newBoard[notTurn]):
                    newBoard[notTurn].remove(change1)
                    newBoard[2].append(change1)
                change2=(change2[0]+x,change2[1]+y)
            newBoard[2].remove((move[1][0],move[1][1],False))
            newBoard[2].append((move[0][0],move[0][1],False))
            newBoard[turn1].remove(move[0])
            move=((move[0][0],move[0][1],False),(move[1][0],move[1][1],move[0][2]))
            newBoard[turn1].append(move[1])
            if(type(k[0])==tuple):
                k=[]
            else:
                k.remove(k[0])
        return newBoard
    @staticmethod
    def evaluate(board1,turn):
        scoreBlack, scoreRed = 0,0
        for i in board1[0]:
            if i[2] is True:
                scoreBlack+=DamkaBina.kingNotStuck(board1,i,turn)
            else:
                scoreBlack+=DamkaBina.placement(i,board1,turn)
        for i in board1[1]:
            if i[2] is True:
                scoreRed+=DamkaBina.kingNotStuck(board1,i,turn)
            else:
                scoreRed +=DamkaBina.placement(i,board1,turn)
        #
        return scoreBlack-scoreRed

    @staticmethod
    def placement(soldier,board,turn):
        counter=14
        if(soldier in board[0]):
            if (soldier[0] == 7):return (DamkaBina.makeKing(soldier, board,'black'))
            elif(soldier[0]==0):counter+=4
            elif(soldier[0]==1):counter+=2
            elif(soldier[0]==2):counter+= 1.2
            elif(soldier[0]==3):counter+= 1
            elif (soldier[0] == 4):counter+=1.4
            elif (soldier[0] == 5):counter+=2.5
            elif (soldier[0] == 6):counter+=4.5
            if(soldier[1]==0 or soldier[1]==7):counter+=1.5
            elif(soldier[1]==2 or soldier[1]==6):counter+=0.3
        elif(soldier in board [1]):
            if (soldier[0] == 0):return (DamkaBina.makeKing(soldier, board,'red'))
            elif (soldier[0] == 7):counter += 4
            elif (soldier[0] == 6):counter += 2
            elif (soldier[0] == 5):counter += 1.2
            elif (soldier[0] == 4):counter += 1
            elif (soldier[0] == 3): counter += 1.4
            elif (soldier[0] == 2):counter += 2.5
            elif (soldier[0] == 1):counter += 4.5
            if (soldier[1] == 0 or soldier[1] == 7):counter += 1.5
            elif (soldier[1] == 2 or soldier[1] == 6):counter+=0.3
        return counter

    @staticmethod
    def legalMoves(i,j,turn,board):#i is color j is empty
        if(turn=='black'):
            if(i[2] is False):
                if(i[0]==j[0]-1):
                    if(i[1]==j[1]+1 or i[1]==j[1]-1):
                        return True
                else:
                    if(DamkaBina.canEat1(board,turn,i,j)):
                        return True
            else:
                txt=DamkaBina.queenMove(i,j,turn,board)
                if(txt=='eat' or txt=='legal'):
                    return True
        else:
            if (i[2] is False):
                if (i[0] == j[0] + 1):
                    return True
                else:
                    if (DamkaBina.canEat1(board, turn, i, j)):
                        return True
            else:
                txt= DamkaBina.queenMove(i, j, turn, board)
                if(txt=='eat' or txt=='legal'):
                    return True
        return False
    @staticmethod
    def queenMove(i,j,turn,board):
        if (abs(i[0]-j[0]) == abs(i[1] - j[1])):  # diagnal line
            return DamkaBina.findDirection(i,j,turn,board)
    @staticmethod
    def findDirection(i,j,turn,board):
        if (i[0] < j[0]):
            if (i[1] < j[1]):
                return(DamkaBina.direction1((i[0]+1,i[1]+  1,True),j,turn,board))
            else:
                return (DamkaBina.direction2((i[0]+1,i[1]-1,True),j,turn,board))
        elif(i[0]>j[0]):
            if (i[1] < j[1]):
                return(DamkaBina.direction3((i[0]-1,i[1]+1,True),j,turn,board))
            else:
                return DamkaBina.direction4((i[0]-1,i[1]-1,True),j,turn,board)
        return 'illegal'
    @staticmethod
    def direction1(i, j, turn, board, counter=0):  # right down
        if (turn == 'black'):
            numT = 0#turn
            numN = 1#not turn
        else:
            numT = 1
            numN = 0
        if (counter == 2):
            return 'illegaal'
        if (i[0] == j[0]):
            if(counter==1):
                return "eat"
            else:
                return 'legal'
        if ((i[0], i[1], False) in board[numT] or (i[0], i[1], True) in board[numT]):
            return False
        if ((i[0], i[1], False) in board[numN] or (i[0], i[1], True) in board[numN]):
            counter += 1
        return DamkaBina.direction1((i[0] + 1, i[1] + 1, False), j, turn, board, counter)
    @staticmethod
    def direction2(i,j,turn,board,counter=0):#up left
        if (turn == 'black'):
            numT = 0
            numN = 1
        else:
            numT = 1
            numN = 0
        if(counter==2):
            return 'illegaal'
        if(i[0]==j[0]):
            if (counter == 1):
                return "eat"
            else:
                return 'legal'
        if((i[0],i[1],False) in board[numT] or (i[0],i[1],True) in board[numT]):
            return False
        if((i[0],i[1],False) in board[numN] or (i[0],i[1],True) in board[numN]):
            counter+=1
        return DamkaBina.direction2((i[0]+1,i[1]-1,False),j,turn,board,counter)
    @staticmethod
    def direction3(i, j, turn, board, counter=0):  #down left
        if (turn == 'black'):
            numT = 0
            numN = 1
        else:
            numT = 1
            numN = 0
        if (counter == 2):
            return 'illegaal'
        if (i[0] == j[0]):
            if (counter == 1):
                return "eat"
            else:
                return 'legal'
        if ((i[0], i[1], False) in board[numT] or (i[0], i[1], True) in board[numT]):
            return False
        if ((i[0], i[1], False) in board[numN] or (i[0], i[1], True) in board[numN]):
            counter += 1
        return DamkaBina.direction3((i[0]-1, i[1]+1, False), j, turn, board, counter)
    @staticmethod
    def direction4(i, j, turn, board, counter=0):  # down right
        if (turn == 'black'):
            numT = 0
            numN = 1
        else:
            numT = 1
            numN = 0
        if (counter == 2):
            return 'illegaal'
        if (i[0] == j[0]):

            if (counter == 1):
                return "eat"
            else:
                return 'legal'
        if ((i[0], i[1], False) in board[numT] or (i[0], i[1], True) in board[numT]):
            return False
        if ((i[0], i[1], False) in board[numN] or (i[0], i[1], True) in board[numN]):
            counter += 1
        return DamkaBina.direction4((i[0]-1, i[1]-1, False), j, turn, board, counter)
    @staticmethod
    def kingNotStuck(board,king,turn):
        black,red,white=board[0],board[1],board[2]
        list=[]
        for i in white:
            txt=DamkaBina.queenMove(king,i,turn,board)
            if(txt=='eat' or txt=='legal'):
                list.append((king,i,txt))
        counter=24
        if(len(list)==0):
            if (king[1] == 0 or king[1] == 7):
                if (king[0] == 0 or king[0] == 7):
                    return 32
                else:
                    return 27
            else:return 24
        else:
            for i in list:
                if(i[2]=='eat'):
                    counter+=1
                else:
                    counter+=0.4
        if(king[1]==0 or king[1]==7):
            if(king[0]==0 or king[0]==7):
                if(len(board[0])>len(board[1])):
                    counter+=16
                else:
                    counter+=4
            else:
                counter+=5
        if(king[0]==0 or king[0]==7):
            counter+=3
        return counter
    @staticmethod
    def makeKing(king,board,turn):
        k=(king[0],king[1],True)
        if(turn=='black'):
            turn=0
        else:turn=1
        board[turn].remove(king)
        board[turn].append(k)
        return DamkaBina.kingNotStuck(board,k,turn)
